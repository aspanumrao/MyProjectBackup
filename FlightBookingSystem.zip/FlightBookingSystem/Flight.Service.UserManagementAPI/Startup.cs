﻿using Flight.Service.UserManagementAPI.DBContext;
using Flight.Service.UserManagementAPI.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight.Service.UserManagementAPI
{
    public class Startup
    {
        private IConfiguration _config { get; }
        public Startup(IConfiguration config)
        {
            _config = config;
        }
 
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var key = "This is my test key";

            services.AddDbContextPool<LoginUserDbContext>(
             options => options.UseSqlServer(_config.GetConnectionString("LoginDBConnection")));
           
            //services.AddTransient<ILoginRepository>(s => new LoginRepository(key));            
        
            //services.AddTransient<ILoginRepository, LoginRepository>(sp =>
            //     {
            //         var factory = sp.GetRequiredService<LoginUserDbContext>();
            //          key = sp.GetRequiredService<string>();
            //         return new LoginRepository(factory, key);
            //     });
                
            services.AddAuthentication(x=>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x=>
                {
                    x.RequireHttpsMetadata = false;
                    x.SaveToken = true;
                    x.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key)),
                        ValidateIssuer=false,
                        ValidateAudience=false
                    };
                 });
            // services.AddSingleton<ILoginRepository>(new LoginRepository(key));
            services.AddScoped<ILoginRepository, LoginRepository>();
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
          
            app.UseMvc();
            app.UseAuthentication();
           
        }
    }
}

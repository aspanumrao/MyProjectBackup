﻿using Flight.Service.UserManagementAPI.DBContext;
using Flight.Service.UserManagementAPI.Model;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Flight.Service.UserManagementAPI.Repository
{
    public class LoginRepository : ILoginRepository
    {
        private readonly LoginUserDbContext _logonuserdbcontext;
        private readonly string _key;

        public LoginRepository(string key)
        {
            this._key = key;
        }
        public LoginRepository(LoginUserDbContext loginUserDbContext)
        {
            _logonuserdbcontext = loginUserDbContext;     
        }
        public void RegisterUser(LoginTbl loginTbl)
        {
            Guid newguid = Guid.NewGuid();
            loginTbl.guid = newguid;
            _logonuserdbcontext.loginTbls.Add(loginTbl);
            _logonuserdbcontext.SaveChanges();
            
        }
       public void RoleAssignment(UserRoleTbl userRoleTbl)
        {
            //what is the username  find the guid 
            //Guid existingguid  = _logonuserdbcontext.loginTbls.Where(a => a.username == loginTbl.username).Select(a=>a.guid).SingleOrDefault();
            //userRoleTbl.guid = existingguid;
            _logonuserdbcontext.userRoleTbls.Add(userRoleTbl);
            _logonuserdbcontext.SaveChanges();
        }
       public string  Authentication(LoginTbl loginTbl)
        {
            if (!_logonuserdbcontext.loginTbls.Where(a=>a.username==loginTbl.username && a.password == loginTbl.password).Any())
            {
                return null;
            }
            //Sceurity handker token

            var tokenhandler = new JwtSecurityTokenHandler();
            var tokenkey = Encoding.ASCII.GetBytes(_key);
            var tokendescriptor = new SecurityTokenDescriptor
            { 
                Subject= new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Name,loginTbl.username)
                }),
                Expires=DateTime.UtcNow.AddHours(1),
                SigningCredentials=
                new SigningCredentials(
                    new SymmetricSecurityKey(tokenkey),
                    SecurityAlgorithms.HmacSha256Signature
                    )
            };
            //get the token 
            var token = tokenhandler.CreateToken(tokendescriptor);

            return tokenhandler.WriteToken(token);
        }
    }
}

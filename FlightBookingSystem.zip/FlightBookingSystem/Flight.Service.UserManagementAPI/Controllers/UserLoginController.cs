﻿using Flight.Service.UserManagementAPI.Model;
using Flight.Service.UserManagementAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using auth=Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XAct.Security;

namespace Flight.Service.UserManagementAPI.Controllers
{
   [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        private readonly ILoginRepository _ILoginRepository;
        public UserLoginController(ILoginRepository loginRepository)
        {
            _ILoginRepository = loginRepository;
        }

        [HttpGet]
        public IEnumerable<string> get()
        {
            return new string[] { "Username", "Password" };
        }

        [HttpPost]
        [Route("new")]
        public void NewUserRegistration([FromBody] LoginTbl loginTbl)
        {
            _ILoginRepository.RegisterUser(loginTbl);

        }


        [HttpPost]
        [Route("role")]
        public void RoleAssign([FromBody] UserRoleTbl userRoleTbl)
        {
            _ILoginRepository.RoleAssignment(userRoleTbl);

        }
       [auth.AllowAnonymous]
        [HttpPost]
        [Route("authen")]
        public IActionResult Authenticate([FromBody] LoginTbl loginTbl)
        {
          var token=  _ILoginRepository.Authentication(loginTbl);
            if (token == null)
            {
                return Unauthorized();
            }
            return Ok();
        }
        [Route("hello")]
        public string hello()
        {
            return "Hi ";
        }

    }
}
